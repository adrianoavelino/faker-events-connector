package com.acme.kafka.connect.sample;

import org.apache.kafka.common.config.Config;
import org.apache.kafka.common.config.ConfigDef;
import org.apache.kafka.common.config.ConfigValue;
import org.apache.kafka.connect.connector.Task;
import org.apache.kafka.connect.errors.ConnectException;
import org.apache.kafka.connect.source.SourceConnector;
import org.apache.kafka.connect.util.ConnectorUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

import static com.acme.kafka.connect.sample.SampleSourceConnectorConfig.*;

public class SampleSourceConnector extends SourceConnector {

    private final Logger log = LoggerFactory.getLogger(SampleSourceConnector.class);

    private Map<String, String> originalProps;
    private SampleSourceConnectorConfig config;
    private SourceMonitorThread sourceMonitorThread;

    /**
     * Retorna a versão do conector definida no arqui src/main/resources/kafka-connect-sample.properties
     * @return
     */
    @Override
    public String version() {
        return PropertiesUtil.getConnectorVersion();
    }

    /**
     * Adiciona as configurações do meu conector, por exemplo topic.name, nas configurações
     * padrões do conector
     * @return ConfigDef
     */
    @Override
    public ConfigDef config() {
        return CONFIG_DEF;
    }

    /**
     * Retorna a task utilizada pelo conector
     * @return
     */
    @Override
    public Class<? extends Task> taskClass() {
        return SampleSourceTask.class;
    }

    /**
     * Aqui você pode utilizar a validação padrão do conector, como no exemplo abaixo,
     * ou customizar alguma validação baseada nas suas propriedades do conector
     *
     * @param connectorConfigs configurações do conector
     * @return
     * throws ConnectException se as configurações do conector estiver nula
     */
    @Override
    public Config validate(Map<String, String> connectorConfigs) {
        Config config = super.validate(connectorConfigs);
        List<ConfigValue> configValues = config.configValues();
        if (validaCampoNulo(configValues)) {
            throw new ConnectException(String.format("%s.config() must return a ConfigDef that is not null.", this.getClass().getName()));
        }
        return config;
    }

    private boolean validaCampoNulo(List<ConfigValue> configValues) {
        return configValues.stream()
                .filter(v -> v.value() == null)
                .findAny()
                .isPresent();
    }

    @Override
    public void start(Map<String, String> originalProps) {
        this.originalProps = originalProps;
        config = new SampleSourceConnectorConfig(originalProps);
        String fields = config.getString(PAYLOAD_VALUE_FIELDS);
        String values = config.getString(PAYLOAD_VALUE_VALUES);
        String headersFields = config.getString(PAYLOAD_HEADERS_FIELDS);
        String headersValues = config.getString(PAYLOAD_HEADERS_VALUES);
        int monitorThreadTimeout = config.getInt(MONITOR_THREAD_TIMEOUT_CONFIG);
        sourceMonitorThread = new SourceMonitorThread(
            context, fields, values, monitorThreadTimeout);
        sourceMonitorThread.start();
    }

    @Override
    public List<Map<String, String>> taskConfigs(int maxTasks) {
        List<Map<String, String>> taskConfigs = new ArrayList<>();
        // The partitions below represent the source's part that
        // would likely to be broken down into tasks... such as
        // tables in a database.
        List<String> partitions = sourceMonitorThread.getCurrentSources();
        if (partitions.isEmpty()) {
            taskConfigs = Collections.emptyList();
            log.warn("No tasks created because there is zero to work on");
        } else {
            int numTasks = Math.min(partitions.size(), maxTasks);
            List<List<String>> partitionSources = ConnectorUtils.groupPartitions(partitions, numTasks);
            for (List<String> source : partitionSources) {
                Map<String, String> taskConfig = new HashMap<>(originalProps);
                taskConfig.put("sources", String.join(",", source));
                taskConfigs.add(taskConfig);
            }
        }
        return taskConfigs;
    }

    @Override
    public void stop() {
        sourceMonitorThread.shutdown();
    }

}
