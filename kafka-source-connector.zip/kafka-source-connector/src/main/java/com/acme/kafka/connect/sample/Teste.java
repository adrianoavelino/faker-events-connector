package com.acme.kafka.connect.sample;

public class Teste {
//    public static void main(String[] args) {
//        Gson gson = new GsonBuilder().create();
//        System.out.println("teste");
//        Faker faker = new Faker(new Locale("pt-BR"));
//        String nome = faker.expression("#{regexify '(s|n){1}'}");
//        System.out.println(nome);
//
//        String fields = "nome,pais,estado,cidade";
//        String values = "#{Name.first_name},#{Address.country},#{Address.state},#{Address.city}";
//
//        HashMap<String, String> mapPayload = new HashMap<>();
//        String[] splitFields = fields.split(",");
//        String[] splitCValues = values.split(",");
//
//        String value;
//        for (int i = 0; i < splitFields.length; i++) {
//            value = faker.expression(splitCValues[i]);
//            mapPayload.put(splitFields[i],value);
//        }
//
//        HashMap<Object, Object> map = new HashMap<>();
//        boolean all = Collections.addAll(List.of("123", "456"));
//        String[] keys = {"123", "456"};
//        map.put("entrytype", "IN");
//        map.put("keys", List.of("123", "456").toArray());
//        System.out.println(gson.toJson(map));
//    }    public static void main(String[] args) {
//        Gson gson = new GsonBuilder().create();
//        System.out.println("teste");
//        Faker faker = new Faker(new Locale("pt-BR"));
//        String nome = faker.expression("#{regexify '(s|n){1}'}");
//        System.out.println(nome);
//
//        String fields = "nome,pais,estado,cidade";
//        String values = "#{Name.first_name},#{Address.country},#{Address.state},#{Address.city}";
//
//        HashMap<String, String> mapPayload = new HashMap<>();
//        String[] splitFields = fields.split(",");
//        String[] splitCValues = values.split(",");
//
//        String value;
//        for (int i = 0; i < splitFields.length; i++) {
//            value = faker.expression(splitCValues[i]);
//            mapPayload.put(splitFields[i],value);
//        }
//
//        HashMap<Object, Object> map = new HashMap<>();
//        boolean all = Collections.addAll(List.of("123", "456"));
//        String[] keys = {"123", "456"};
//        map.put("entrytype", "IN");
//        map.put("keys", List.of("123", "456").toArray());
//        System.out.println(gson.toJson(map));
//    }
}

//class Key {
//    private  List<String> keys;
//
//    public Key() {
//        this.keys = List.of("123", "456");
//    }
//}
