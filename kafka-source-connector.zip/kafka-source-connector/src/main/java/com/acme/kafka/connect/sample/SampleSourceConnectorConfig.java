package com.acme.kafka.connect.sample;

import java.util.Map;

import org.apache.kafka.common.config.AbstractConfig;
import org.apache.kafka.common.config.ConfigDef;
import org.apache.kafka.common.config.ConfigDef.Importance;
import org.apache.kafka.common.config.ConfigDef.Type;

public class SampleSourceConnectorConfig extends AbstractConfig {

    public SampleSourceConnectorConfig(final Map<?, ?> originalProps) {
        super(CONFIG_DEF, originalProps);
    }
    public static final String TOPIC_NAME = "topic.name";
    private static final String TOPIC_NAME_DOC = "This is the name of the topic ";
    private static final String TOPIC_NAME_DEFAULT = "topico1";

    public static final String PAYLOAD_VALUE_FIELDS = "payload.value.fields";
    private static final String PAYLOAD_VALUE_FIELDS_DOC = "These are the names of fields ";

    public static final String PAYLOAD_VALUE_VALUES = "payload.value.values";
    private static final String PAYLOAD_VALUE_VALUES_DOC = "These are the values of expressions from the Faker library to generate texts, messages, etc";

    public static final String PAYLOAD_HEADERS_FIELDS = "payload.headers.fields";
    private static final String PAYLOAD_HEADERS_FIELDS_DOC = "These are the names of fields from the header";
    private static final String PAYLOAD_HEADERS_FIELDS_DEFAULT = "id";

    public static final String PAYLOAD_HEADERS_VALUES = "payload.headers.values";
    private static final String PAYLOAD_HEADERS_VALUES_DOC = "These are the values of expressions from the Faker library to generate texts, messages, etc to the header";
    private static final String PAYLOAD_HEADERS_VALUES_DEFAULT = "#{number.number_between '1','9999999'}";

    public static final String MONITOR_THREAD_TIMEOUT_CONFIG = "monitor.thread.timeout";
    private static final String MONITOR_THREAD_TIMEOUT_DOC = "Timeout used by the monitoring thread";
    private static final int MONITOR_THREAD_TIMEOUT_DEFAULT = 10000;

    public static final ConfigDef CONFIG_DEF = createConfigDef();

    private static ConfigDef createConfigDef() {
        ConfigDef configDef = new ConfigDef();
        addParams(configDef);
        return configDef;
    }

    private static void addParams(final ConfigDef configDef) {
        configDef

        // propriedade obrigatórias
        /**
         * Para definir uma propriedade obrigatória, basta utilizar o construtor
         * sem passar o valor default
         */
        .define(PAYLOAD_VALUE_FIELDS, Type.STRING, Importance.HIGH, PAYLOAD_VALUE_FIELDS_DOC)
        .define(PAYLOAD_VALUE_VALUES, Type.STRING, Importance.HIGH, PAYLOAD_VALUE_VALUES_DOC)

        // propriedades não obrigatórias
        .define(TOPIC_NAME, Type.STRING, TOPIC_NAME_DEFAULT, Importance.LOW, TOPIC_NAME_DOC)
        .define(PAYLOAD_HEADERS_FIELDS, Type.STRING, PAYLOAD_HEADERS_FIELDS_DEFAULT,
                Importance.LOW, PAYLOAD_HEADERS_FIELDS_DOC)
        .define(PAYLOAD_HEADERS_VALUES, Type.STRING, PAYLOAD_HEADERS_VALUES_DEFAULT,
                Importance.LOW, PAYLOAD_HEADERS_VALUES_DOC)
        .define(MONITOR_THREAD_TIMEOUT_CONFIG, Type.INT, MONITOR_THREAD_TIMEOUT_DEFAULT,
                Importance.LOW, MONITOR_THREAD_TIMEOUT_DOC);
    }
}
