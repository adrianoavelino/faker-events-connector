package com.acme.kafka.connect.sample;

import com.github.javafaker.Faker;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.kafka.connect.data.Schema;
import org.apache.kafka.connect.source.SourceRecord;
import org.apache.kafka.connect.source.SourceTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

import static com.acme.kafka.connect.sample.SampleSourceConnectorConfig.*;

public class SampleSourceTask extends SourceTask {

    private static Logger log = LoggerFactory.getLogger(SampleSourceTask.class);

    private SampleSourceConnectorConfig config;
    private int monitorThreadTimeout;
    private List<String> sources;
    private Map<String, String> props = new HashMap<>();
    private String fields;
    private String values;
    private String keysFields;
    private String keysValues;
    private String topicName;

    @Override
    public String version() {
        return PropertiesUtil.getConnectorVersion();
    }

    /**
     * recuperar os valores das propriedades para realizar alguma operação
     * @param properties
     */
    @Override
    public void start(Map<String, String> properties) {
        config = new SampleSourceConnectorConfig(properties);
        monitorThreadTimeout = config.getInt(MONITOR_THREAD_TIMEOUT_CONFIG);
        String sourcesStr = properties.get("sources");
        sources = Arrays.asList(sourcesStr.split(","));
        this.props = config.originalsStrings();
        this.fields = config.getString(PAYLOAD_VALUE_FIELDS);
        this.values = config.getString(PAYLOAD_VALUE_VALUES);
        this.keysFields = config.getString(PAYLOAD_HEADERS_FIELDS);
        this.keysValues = config.getString(PAYLOAD_HEADERS_VALUES);
        this.topicName = config.getString(TOPIC_NAME);

        //aqui devo criar algo para criar diversos tópicos
        /// List.of("teste","payload.topico1.valor").stream().filter(x -> x.matches("^payload.*")).collect(Collectors.toList()).get(0).split("\\.")
    }

    @Override
    public List<SourceRecord> poll() throws InterruptedException {
        Thread.sleep(monitorThreadTimeout / 2);
        List<SourceRecord> records = new ArrayList<>();
        Faker faker = new Faker(new Locale("pt-BR"));
        Gson gson = new GsonBuilder().create();

        HashMap<String, String> mapPayloadValue = new HashMap<>();
        HashMap<String, String> mapPayloadKey = new HashMap<>();
        String[] splitFields = fields.split(",");
        String[] splitValues = values.split(",");
        String[] splitKeysFields = keysFields.split(",");
        String[] splitKeysValues = keysValues.split(",");

            for (String source : sources) {
            log.info("Polling key fields" + gson.toJson(splitKeysFields));
            log.info("Polling key values" + gson.toJson(splitKeysValues));

                SourceRecord sourceRecord = new SourceRecord(Collections.singletonMap("source", source),
                        Collections.singletonMap("offset", 0),
                        source,
                        Schema.BYTES_SCHEMA,
                        String.format(gson.toJson(mapPayloadValue)).getBytes()
                );

                String value;
                for (int i = 0; i < splitFields.length; i++) {
                    value = faker.expression(splitValues[i]);
                    String key = splitFields[i];
                    mapPayloadValue.put(key, value);
                }

                for (int i = 0; i < splitKeysFields.length; i++) {
                    value = faker.expression(splitKeysValues[i]);
                    String key = splitKeysFields[i];
                    mapPayloadKey.put(key, value);
                }

                SourceRecord sourceRecord2 = new SourceRecord(Collections.singletonMap("source", source),
                        Collections.singletonMap("offset", 0),
                        topicName,
                        null,
                        Schema.BYTES_SCHEMA,
                        gson.toJson(mapPayloadKey).getBytes(),
                        Schema.BYTES_SCHEMA,
                        gson.toJson(mapPayloadValue).getBytes()
                        );
                records.add(sourceRecord2);
//                records.add(sourceRecord);
            }
        return records;
    }

    @Override
    public void stop() {
    }

}
