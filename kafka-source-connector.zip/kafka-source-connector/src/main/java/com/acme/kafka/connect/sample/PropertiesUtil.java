package com.acme.kafka.connect.sample;

import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class PropertiesUtil {

    private static final String CONNECTOR_VERSION = "connector.version";

    private static Logger log = LoggerFactory.getLogger(PropertiesUtil.class);
    private static String propertiesFile = "/kafka-connect-sample.properties";
    private static Properties properties;

    /**
     * Lê o arquivo src/main/resources/kafka-connect-sample.properties
     * e alimenta os valores no campo this.properties
     */
    static {
        try (InputStream stream = PropertiesUtil.class.getResourceAsStream(propertiesFile)) {
            properties = new Properties();
            properties.load(stream);
        } catch (Exception ex) {
            log.warn("Error while loading properties: ", ex);
        }
    }

    /**
     * Retorna a versão do conector
     *
     * A Versão do conector está definida no arquivo src/main/resources/kafka-connect-sample.properties
     * @return
     */
    public static String getConnectorVersion() {
        return properties.getProperty(CONNECTOR_VERSION);
    }

    /**
     * Construtor default privado
     *
     * Como é uma classe auxiliar e o método será utilizado de forma estática
     * não é necessário a utilização de uma instância utilizando new
     */
    private PropertiesUtil() {
    }

}
