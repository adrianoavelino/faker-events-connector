package com.acme.kafka.connect.sample;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.common.config.ConfigException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static com.acme.kafka.connect.sample.SampleSourceConnectorConfig.*;

public class SampleSourceConnectorConfigTest {

    /**
     * Teste unitário verifica se algum valor de uma propriedade obrigatória
     *  não foi declarado
     */
    @Test
    public void basicParamsAreMandatory() {
        assertThrows(ConfigException.class, () -> {
            Map<String, String> props = new HashMap<>();
            new SampleSourceConnectorConfig(props);
        });
    }

    /**
     * Verifica os valores default das propriedades
     * Para identificar os valores default visualize a classe SampleSourceConnectorConfig e verifique as
     * constantes com os nome *DEFAULT e que devem estar declaradas dentro do método
     */
    @Test
    public void checkingNonRequiredDefaults() {
        Map<String, String> props = new HashMap<>();
        props.put(PAYLOAD_VALUE_FIELDS, "nome");
        props.put(PAYLOAD_VALUE_VALUES, "#{}");
        SampleSourceConnectorConfig config = new SampleSourceConnectorConfig(props);
        assertEquals("id", config.getString(PAYLOAD_HEADERS_FIELDS));
        assertEquals("#{number.number_between '1','9999999'}", config.getString(PAYLOAD_HEADERS_VALUES));
    }

}
