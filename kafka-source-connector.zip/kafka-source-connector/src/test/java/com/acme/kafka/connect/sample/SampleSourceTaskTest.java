package com.acme.kafka.connect.sample;

import org.apache.kafka.connect.source.SourceRecord;
import org.hamcrest.CoreMatchers;
import org.hamcrest.Matcher;
import org.hamcrest.MatcherAssert;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.testcontainers.shaded.org.hamcrest.Matchers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.acme.kafka.connect.sample.SampleSourceConnectorConfig.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.testcontainers.shaded.org.hamcrest.Matchers.*;

public class SampleSourceTaskTest {

    @Test
    public void taskVersionShouldMatch() {
        String version = PropertiesUtil.getConnectorVersion();
        assertEquals(version, new SampleSourceTask().version());
    }

    @Test
    public void checkNumberOfRecords() {
        Map<String, String> connectorProps = new HashMap<>();
        connectorProps.put(PAYLOAD_VALUE_FIELDS, "nome");
        connectorProps.put(PAYLOAD_VALUE_VALUES, "#{Name.first_name}");
        connectorProps.put(PAYLOAD_HEADERS_FIELDS, "id");
        connectorProps.put(PAYLOAD_HEADERS_VALUES, "#{Internet.uuid}");
        connectorProps.put("payload.table.field", "teste");
        Map<String, String> taskProps = getTaskProps(connectorProps);
        SampleSourceTask task = new SampleSourceTask();
        assertDoesNotThrow(() -> {
            task.start(taskProps);
            List<SourceRecord> records = task.poll();
            assertEquals(3, records.size());
        });
    }


    @Test
    public void checkKeyValuesFromRecords() throws InterruptedException {
        Map<String, String> connectorProps = new HashMap<>();
        connectorProps.put(PAYLOAD_VALUE_FIELDS, "nome");
        connectorProps.put(PAYLOAD_VALUE_VALUES, "#{Name.first_name}");
        connectorProps.put(PAYLOAD_HEADERS_FIELDS, "id");
        connectorProps.put(PAYLOAD_HEADERS_VALUES, "#{Internet.uuid}");

        Map<String, String> taskProps = getTaskProps(connectorProps);
        SampleSourceTask task = new SampleSourceTask();
        task.start(taskProps);
        List<SourceRecord> sourceRecords = task.poll();
        int size = sourceRecords.size();
        assertEquals(3, size);
        String key = new String((byte[])sourceRecords.get(0).key());

        MatcherAssert.assertThat(key, CoreMatchers.containsString("id"));
    }

    private Map<String, String> getTaskProps(Map<String, String> connectorProps) {
        SampleSourceConnector connector = new SampleSourceConnector();
        connector.start(connectorProps);
        List<Map<String, String>> taskConfigs = connector.taskConfigs(1);
        return taskConfigs.get(0);
    }
    
}
